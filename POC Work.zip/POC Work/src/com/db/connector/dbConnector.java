
package com.db.connector;

import java.sql.*;


public class dbConnector {
    public static Connection con; 

	public dbConnector() throws Exception
    {
    Class.forName("com.mysql.jdbc.Driver");
    con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/POC_work", "root", "2710");
    System.out.println("connection made");
    }
    }


