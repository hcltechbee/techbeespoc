package com.constants;

public class QueryConstants {
	public final String displayAllUsers="select * from user905";
	public final String deleteUsers="delete from user905 where id=?";
	public final String searchUser="select * from user905 where name=?";
}
