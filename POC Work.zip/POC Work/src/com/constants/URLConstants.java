package com.constants;

import java.sql.Connection;

public class URLConstants {
	public static String dataBaseURL="jdbc:mysql://localhost:3306/keshavdb";
	public static String dataBaseUserName="root";
	public static String dataBasePassword="Keshav@2313";
	public final String dataBaseDriver="com.mysql.jdbc.Driver";
	public Connection dataBaseConnection=null; 
}
