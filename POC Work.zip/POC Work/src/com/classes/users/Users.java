package com.classes.users;

public class Users {
	private int id;  
	private String name,password,email,country;
	
	/*----------------------------------------------------Getter And Setter For ID---------------------------------*/
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	/*----------------------------------------------------Getter And Setter For Name---------------------------------*/
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	/*----------------------------------------------------Getter And Setter For Password---------------------------------*/
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	/*----------------------------------------------------Getter And Setter For EMAIL---------------------------------*/
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	/*----------------------------------------------------Getter And Setter For Country---------------------------------*/
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	} 

}  